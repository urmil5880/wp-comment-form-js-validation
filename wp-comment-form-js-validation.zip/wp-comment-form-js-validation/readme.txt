=== WP Comment Form Js Validation ===

Contributors: urmilwp
Tags: jquery comment form validation, Comment form validation, Advance comment form validation, Client side comment form validation, javascript comment form validation, form validation, plugin Development
Requires PHP: 5
Stable tag: 1.0
Version: 1.0 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin use for wordpress comments validation to the comment form.
= Features =
* easy to install
* No need to settings in admin area

= Contact =
* If you have any suggestion, feel free to email me at urmil.bca5880@gmail.com

== Installation ==

1. Go to Plugins > Add New. 
2. Searh "wp comment form js validation"
3. install and activate the WordPress Plugin.


== How to Use ==

only need to activate the plugin.


== Screenshots ==

1. screenshot-1.png
